export class StorageEngineFactory {

  constructor(storageEngines) {
  }

}
