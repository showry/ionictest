import {CloudSettings} from "@ionic/cloud-angular";
import {Config, ConfigInterface} from "./config-class";
import {readConfig} from "./config-reader";
import {ENVIRONMENT} from "../../environment";

let config: Config = new Config(readConfig() as ConfigInterface);
config.environment = ENVIRONMENT;
let cloudSettings: CloudSettings = {core: {app_id: "d2590f5e"}};

export {config, cloudSettings};
