import {User} from "../../models/user";
import {AuthService} from "./auth-service";

export function currentUser(): User {
  return AuthService.currentUser;
}
