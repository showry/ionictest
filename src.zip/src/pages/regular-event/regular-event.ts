import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

@IonicPage({})
@Component({
  selector: 'page-regular-event',
  templateUrl: 'regular-event.html',
})
export class RegularEventPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

}
