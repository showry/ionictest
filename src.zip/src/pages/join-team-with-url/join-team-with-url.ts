import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {AuthService} from "../../providers/pidge-client/auth-service";
import {StandardResponseAlert} from "../../providers/services/standard-response-alert";
import {LoadingPage} from "../loading/loading";
import {LoginPage} from "../login/login";
import {ChatService,PuplicUrl} from "../../providers/pidge-client/chat-service";
import {HomePage} from "../home/home";

/**
 * Generated class for the JoinTeamWithUrlPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-join-team-with-url',
  templateUrl: 'join-team-with-url.html',
})
export class JoinTeamWithUrlPage {
protected urlKey:string;
protected urlObject:PuplicUrl;
protected showTeamDetail:boolean=false;
  constructor(protected authService: AuthService,
              protected standardAlert: StandardResponseAlert,
              protected chatService: ChatService,
              public navCtrl: NavController, public navParams: NavParams) {

    // this.authService.loginLastUser()
    // .then(user => this.init(user))
    // .catch(e => this.authenticateFirst());
    this.urlKey=this.navParams.get('urlKey');
       this.getPublicUrlInfo();
  }
  protected init(user) {
    if (!user) {
      
      return this.authenticateFirst();
    }
    else {

      this.urlKey=this.navParams.get('urlKey');
      return ;
      }
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad JoinTeamWithUrlPage');
  }
  protected authenticateFirst() {
    return this.showError("Please authenticate")
      .then(() => this.navCtrl.setRoot('LoadingPage'))
      .then(() => LoadingPage.loadedChange(true, 'LoginPage'))
      ;
  }
  protected showError(error) {
    return this.standardAlert.showError(error);
  }
  protected getPublicUrlInfo(){
  console.log('url key',this.urlKey);
    Promise.resolve(this.chatService.getPublicUrlInfo(this.urlKey))
    .then(publicUrl=>{console.log('public url info',publicUrl);this.urlObject=publicUrl;console.log('urls in Interface object',this.urlObject);this.showTeamDetail=true;})
    .catch(error =>this.showError(error))
  
  }
  protected joinTeam()
  {
       Promise.resolve(this.chatService.joinTeamWithUrl(this.urlObject.linkable,this.urlObject))
    .then(publicUrl=>{this.urlObject=publicUrl;this.standardAlert.showSuccess('Success ,You Joined Team')})
    .then(()=>this.navCtrl.setRoot('HomePage'))
    .catch(error =>{this.showError(error)})
  }
}
