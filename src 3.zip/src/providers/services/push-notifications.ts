import {Injectable} from "@angular/core";
import {ToastController} from "ionic-angular";

@Injectable()
export class PushNotifications {

  constructor(protected toastCtrl: ToastController) {

  }

  public register() {

  }

}
