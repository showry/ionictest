import {Environments} from "./providers/config/environments";

 //export const ENVIRONMENT : Environments = Environments.Production;
 export const ENVIRONMENT : Environments = Environments.Development;
