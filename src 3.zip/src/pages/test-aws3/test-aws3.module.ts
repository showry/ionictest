import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TestAws3Page } from './test-aws3';

@NgModule({
  declarations: [
    TestAws3Page,
  ],
  imports: [
    IonicPageModule.forChild(TestAws3Page),
  ],
})
export class TestAws3PageModule {}
