import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {AuthService} from "../../providers/pidge-client/auth-service";
import {StandardResponseAlert} from "../../providers/services/standard-response-alert";
import {LoginPage} from "../login/login";
<<<<<<< HEAD
import {ChatService,PuplicUrl} from "../../providers/pidge-client/chat-service";
import {HomePage} from "../home/home";
=======
import {ChatService, PuplicUrl} from "../../providers/pidge-client/chat-service";
>>>>>>> 94cf415ac73dae5ea0114f6654093fd4e7c7db6e
import {LoadingStacker} from "../../providers/stacker/loading-stacker";
import {AnalyticsLogger} from "../../providers/services/analytics-logger";
import {currentUser} from "../../providers/pidge-client/current-user";
import {RegisterPage} from "../register/register";

/**
 * Generated class for the JoinTeamWithUrlPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@IonicPage({segment: '/public-url/:urlKey'})
@Component({
  selector: 'page-join-team-with-url',
  templateUrl: 'join-team-with-url.html',
})
export class JoinTeamWithUrlPage {
<<<<<<< HEAD
protected urlKey:string;
protected urlObject:PuplicUrl;
protected showTeamDetail:boolean=false;
  constructor(protected authService: AuthService,
              protected standardAlert: StandardResponseAlert,
              protected chatService: ChatService,
              protected loadingStacker: LoadingStacker,
              protected navCtrl: NavController, protected navParams: NavParams) {

    // this.authService.loginLastUser()
    // .then(user => this.init(user))
    // .catch(e => this.authenticateFirst());
    // this.urlKey=this.navParams.get('urlKey');
    //    this.getPublicUrlInfo();
=======

  protected urlKey: string;
  protected urlObject: PuplicUrl;
  protected showTeamDetail: boolean = false;

  constructor(protected standardAlert: StandardResponseAlert,
              protected chatService: ChatService,
              protected navCtrl: NavController,
              protected analytics: AnalyticsLogger,
              protected navParams: NavParams,
              protected loadingStacker: LoadingStacker) {

>>>>>>> 94cf415ac73dae5ea0114f6654093fd4e7c7db6e
    this.urlKey = this.navParams.get('urlKey');
    Promise.resolve(this.loadingStacker.add())
      .then(() => this.getPublicUrlInfo())
      .catch(e => this.standardAlert.showError(e))
      .then(() => this.loadingStacker.pop());
  }
<<<<<<< HEAD
  protected init(user) {
    if (!user) {
      
      return this.authenticateFirst();
    }
    else {

      this.urlKey=this.navParams.get('urlKey');
      return ;
      }
  }
=======

>>>>>>> 94cf415ac73dae5ea0114f6654093fd4e7c7db6e
  ionViewDidLoad() {
    this.analytics.ga().then(ga => ga.trackView('Team Public Invitation Page'));
  }
  protected authenticateFirst() {
    return this.standardAlert.showInfo("Please signup/login first, then try again.", [
      {
        text: 'Register',
        role: 'cancel',
        handler: () => {
          this.navCtrl.push(RegisterPage);
        }
      },
      {
        text: 'Login',
        role: 'cancel',
        handler: () => {
          this.navCtrl.push(LoginPage);
        }
      }
    ]);
  }
  protected showError(error) {
    return this.standardAlert.showError(error);
  }
<<<<<<< HEAD
  protected getPublicUrlInfo(){
  console.log('url key',this.urlKey);
    Promise.resolve(this.chatService.getPublicUrlInfo(this.urlKey))
    .then(publicUrl=>{console.log('public url info',publicUrl);this.urlObject=publicUrl;console.log('urls in Interface object',this.urlObject);this.showTeamDetail=true;})
    .catch(error =>this.showError(error))
  
  }
  protected joinTeam()
  {
       Promise.resolve(this.chatService.joinTeamWithUrl(this.urlObject.linkable,this.urlObject))
    .then(publicUrl=>{this.urlObject=publicUrl;this.standardAlert.showSuccess('Success ,You Joined Team')})
    .then(()=>this.navCtrl.setRoot('HomePage'))
    .catch(error =>{this.showError(error)})
=======

  protected getPublicUrlInfo() {

    return Promise.resolve(this.chatService.getPublicUrlInfo(this.urlKey))
      .then(publicUrl => this.urlObject = publicUrl)
      .catch(error => this.showError(error));

  }

  protected joinTeam() {
    return Promise.resolve(this.loadingStacker.add())
      .then(() => currentUser())
      .then(user => user ? Promise.resolve(user) : Promise.reject(this.authenticateFirst()))
      .then(user => this.chatService.joinTeamWithUrl(this.urlObject.linkable, this.urlObject))
      .then(() => this.standardAlert.showSuccess('You did it! Welcome on board, again!'))
      .catch(e => null)
      .then(() => this.loadingStacker.pop())
      ;
>>>>>>> 94cf415ac73dae5ea0114f6654093fd4e7c7db6e
  }
}
